A party cosisting of 
[[Caius]]
[[Eadan]]
[[Galmythe]]
[[Garrett]]
[[R'lykum]]
[[Solstice]]