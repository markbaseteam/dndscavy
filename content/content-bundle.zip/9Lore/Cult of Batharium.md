> [!infobox]
> # Caius
> ![[[GarrettP.png|cover hsmall]]
> ###### Basic Information
> | Type |  Stat |
> | ---- | ---- |
> | *Leader*|???|
> | *Base of Operations | ??? |
> |*Alignment *| ??? |
> 
> ###### Relationships
>| Type |  Stat |
>| ---- | ---- | 
>|*Hostility*|???|
>
>  ###### Key Members
>| File | Race | Gender|
>| ---- | ---- |  ---- | 
>|???|???|???|