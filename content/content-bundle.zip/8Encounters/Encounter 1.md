> [!infobox]
> # Wolfs
> ![[wolvesP.jpg|cover hsmall]]
> 
> | What we fought|
> | ---- |
|2 Smal wolf and 1 big|
> 
> |Where|
>  | ---- | 
>  |Cave near [[Napur]] |
>  
>|Relevant Skills/Spells|
>| ---- |
>|None|
>
>|Loot Acquired|
>| ---- | 
>|Capturd the big wolfe and gave it to [[Acererak]]|
>
>|Session Fought in|
>| ---- |
>|Session don't know|

### <big> <big><big><big> Other Notes