> [!infobox]
> # Name
> ![[GarrettP.png|cover hsmall]]
> 
> | What we fought|
> | ---- |
|  3 bandis 8 barbarien |
> 
> |Where|
>  | ---- |
>  | Ruend villes |
>  
>|Relevant Skills/Spells|
>| ---- |
>| ?? |
>
>|Loot Acquired|
>| ---- |
>| Poki bals and pole of expandin |
>
>|Session Fought in|
>| ---- |
>| 11 |

### <big> <big><big><big> Other Notes