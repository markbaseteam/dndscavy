Dungeon

East Pond

fountain  tap

koi fish  Kay

Chest Inside Dimond(200G)

Monolisk black med  engraved flams text cerkel of life

Braser  eggs bird  bird on flames

Stone dagger

North Fire

Door right text  Elvish  the kay to my chamber lies in the burnt wood

West storm

Northwell bonfire med 7 people

Stone Staff and crossbow greadsword

South Cultist

Fighter Druid barbarian ranger 

Wall  behind cultist statue