> [!infobox]
> # Isaac
> ![[IsaacP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|Alive|
> *Class*| ?? |
> *Level*|??|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | ?? |
> *Gender* | Male |
> *Height*| ?213|
> *Hair*|??|
> *Eyes*|??|
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*|Tavern in [[Napur]]|
>  *Relevance To Party*|Paid [[Garrett]] to baby  sit them|
>  *Any Relations/Family*|??|

### <big><big>Other Important Information
know giant,  Knows [[Garrett]]