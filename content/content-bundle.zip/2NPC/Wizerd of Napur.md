> [!infobox]
> # ???
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|Dead|
> *Class*| Wizard |
> *Level*|??|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | Human |
> *Gender* | Male |
> *Height*| ?? |
> *Hair*|??|
> *Eyes*|??|
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*|magic shop in [[Napur]]|
>  *Relevance To Party*|Killed him for no reason|
>  *Any Relations/Family*|  Same order as [[Priest of Batharium]]  |

### <big><big><big>Other Important Information
Did nothing wrong, Owned a magic shop

Killed2.5 taims

[[Batharium]]