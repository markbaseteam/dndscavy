> [!infobox]
> # ðeroquoeraelrl
> ![[ðeroquoeraelrlP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|Alive|
> *Class*| ?? |
> *Level*|??|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| 40-50|
> *Race* | Leonin |
> *Gender* | Male   |
> *Height*| 274 |
> *Hair*|Brown|
> *Eyes* | Blu | 
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*|On the road fron [[Napur]] to [[Varkaat]]|
>  *Relevance To Party*|Travelt with from [[Napur]] to [[Crossing Between Kingdoms]] |
>  *Any Relations/Family*|[[Machno]]|

### <big><big><big>Other Important Information
BADASS