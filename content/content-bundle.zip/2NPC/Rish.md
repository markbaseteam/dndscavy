> [!infobox]
> # Rish
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|Alive|
> *Class*| Clenar |
> *Level*|??|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| 30+|
> *Race* | Half-Elf|
> *Gender* | Male |
> *Height*| 172|
> *Hair*|??|
> *Eyes*|??|
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*|In a cave near [[Napur]]|
>  *Relevance To Party* | [[Encounter 1]]|
>  *Any Relations/Family*|Works for [[Acererak]]|

### <big><big><big>Other Important Information
work for[[Acererak]] as a “cleaner”