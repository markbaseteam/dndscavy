> [!infobox]
> # Sisyphus
> ![[SisyphusP.png|]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| Unknown was last seen alive with [[RA]] |
> *Class*| Blacksmith from a dwarven city and a warrior in war |
> *Level*| ?? |
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | Human (resembling a goliath) |
> *Gender* | Male  |
> *Height*| ?? |
> *Hair*| Black long hair |
> *Eyes*| Coverd but sand is runing  out from them |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| A cell in the tempel of [[RA]] [[Session 15]] |
>  *Relevance To Party*| Unknown as we betraid him |
>  *Any Relations/Family*| ?? |
>

### <big><big><big>Other Important Information

Met [[Sisyphus]] in a cell in [[The Gaze of RA]]
Kidnap by the  [[Cult of RA|cultist of RA]] was held there for A few weeks 2-4


Has **Blindsight**