[[Kill Werewolf]]

> [!infobox]
> # Name
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| Dead |
> *Class*| ?? |
> *Level*| ??| 
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ?? |
> *Race* | Human |
> *Gender* | Male  |
> *Height*| ?? |
> *Hair*|Short Silver|
> *Eyes*| ?? |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| ?? |
>  *Relevance To Party*| Killed by party |
>  *Any Relations/Family*| ?? |

### <big><big><big>Other Important Information
Was the [[Kill Werewolf|Werewolf]]