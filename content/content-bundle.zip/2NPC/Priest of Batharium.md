> [!infobox]
> # ???
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| Alive |
> *Class*| ?? |
> *Level*| ?? |
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| 30+ |
> *Race* | Leonin |
> *Gender* | Male |
> *Height*| 220 |
> *Hair*| ?? |
> *Eyes*| ?? |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| [[The Bridge Between Worlds]] |
>  *Relevance To Party*| Want the book that [[R'lykum]] has And the armor [[Caius]] has |
>  *Any Relations/Family*| Same order as [[Wizerd of Napur]] |

### <big><big><big>Other Important Information
wants the [[Religious book of batharium|book]] back