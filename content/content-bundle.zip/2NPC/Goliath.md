> [!infobox]
> # ???
> ![[GoliathP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| Alive |
> *Class*| ?? |
> *Level*| ?? |
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | Goliath |
> *Gender* | Male   |
> *Height*| 15-16 feat |
> *Hair*| None |
> *Eyes*| ?? |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| outside of the cave in [[Crossing Between Kingdoms]] |
>  *Relevance To Party*| Tooke the bock back and armor |
>  *Any Relations/Family*| [[Priest of Batharium]] |

### <big><big><big>Other Important Information
Got the [[Religious book of batharium|Book]] back