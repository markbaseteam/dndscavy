> [!infobox]
> # Grobla
> ![[GarrettP.png]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| ?? |
> *Class*| ?? |
> *Level*| ?? |
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | ?? |
> *Gender* | Female  |
> *Height*| ?? |
> *Hair*| ?? |
> *Eyes*| ?? |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| [[The Gaze of RA]]|
>  *Relevance To Party*| Pet |
>  *Any Relations/Family*| ?? |

### <big><big><big>Other Important Information


