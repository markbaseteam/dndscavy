
> [!infobox]
> # Benjamin
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|Alive|
> *Class*| Tavern Keeper |
> *Level*|??|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| 40-45|
> *Race* | Human |
> *Gender* | Male  |
> *Height*| 155 |
> *Hair*|??|
> *Eyes*|??|
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*|Tavern in [[Varkaat]]|
>  *Relevance To Party*|Gave us a quest [[Kill Werewolf]]|
>  *Any Relations/Family*|??|

### <big><big><big>Other Important Information
Owns a tavern in [[Varkaat]]

Quest to kill a [[Kill Werewolf|Werewolf]]