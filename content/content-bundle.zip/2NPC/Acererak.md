 > [!infobox]
> # Acererak
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|Alive|
> *Class*|Summoner|
> *Level*|??|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| 70+|
> *Race* |Firbolg|
> *Gender* | Male |
> *Height*| ?? |
> *Hair*|??|
> *Eyes*|??|
> 
> ###### General Information
> |  |  |
>  | ---- | ---- |
>  *Where We Me*|Tower near [[Napur]]|
>  *Relevance To Party*|We did a job for him [[Encounter 1]]|
>  *Any Relations/Family*|Emplous [[Rish]] |

### <big><big><big>Other Important Information
summoned a Gwyllgi ,
Making a book, 
has dementia(Bad memory)
summoned the rain 