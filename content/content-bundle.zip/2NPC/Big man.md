> [!infobox]
> # Big Man
> ![[BigmanP.png]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| Alive |
> *Class*| ?? |
> *Level*| ?? |
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | ?? |
> *Gender* | Masculin |
> *Height*| 20+ |
> *Hair*| None |
> *Eyes*| Horns |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| Cave in [[Crossing Between Kingdoms]] |
>  *Relevance To Party*| Gradient of wishes to try and free him |
>  *Any Relations/Family*| ?? |

### <big><big><big>Other Important Information
Plays the banjo


