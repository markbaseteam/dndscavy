> [!infobox]
> # Name
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|??|
> *Class*| ?? |
> *Level*|??|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | ?? |
> *Gender* | Male or Female  |
> *Height*| ?? |
> *Hair*|??|
> *Eyes*|??|
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*|??|
>  *Relevance To Party*|??|
>  *Any Relations/Family*|[[ðeroquoeraelrl]]|

### <big><big><big>Other Important Information