

> [!infobox]
> # Kill Werewolf
> ![[WarewolfP.jpg|cover hsmall]]
> 
> ### Objective: 
> ```Kill a Werewolf```
> 
> ###  Quest Giver
> [[Benjamin]]
> 
> ### Location
> [[Napur]]
> 
> ### Reward
>``` 39G Silver rapier```
> ###  Faction

when we arrived to [[Napur]] we found a notis bord and a notis of a Werewolf we went to the tavern and med with [[Benjamin]] an made a deal to kill a Werewolf for 39g and one silver rapier