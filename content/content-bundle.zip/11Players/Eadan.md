> [!infobox]
> # Caius
> ![[EadanP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |