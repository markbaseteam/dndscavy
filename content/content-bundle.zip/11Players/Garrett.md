> [!infobox]
> # Garrett
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*|Alive
> *Class*| Ranger |
> *Level*|6|
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| 30
> *Race* | Human |
> *Gender* | Man |
> *Height*| 170 |
> *Hair*|Brown
> *Eyes*|Black and one Green