> [!infobox]
> # Caius
> ![[TyrnanP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |Tyrnan "Rainfall" Em Snakesnarl