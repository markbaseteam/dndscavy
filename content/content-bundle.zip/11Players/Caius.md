> [!infobox]
> # Name
> ![[CaiusP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| Alive |
> *Class*| Paladin |
> *Level*| 6 |
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | Fallen Aasimar |
> *Gender* | Male   |
> *Height*| 185 |
> *Hair*| ?? |
> *Eyes*| ?? |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| Taver in [[Napur]] |
>  *Relevance To Party*| ?? |
>  *Any Relations/Family*| ?? |

### <big><big><big>Other Important Information
