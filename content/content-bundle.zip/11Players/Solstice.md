> [!infobox]
> # Caius
> ![[SolsticeP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |