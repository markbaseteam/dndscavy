> [!infobox]
> # Caius
> ![[R'lykumP.jpg]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |

Hade the [[Religious book of batharium|book]]