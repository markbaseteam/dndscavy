> [!infobox]
> # Name
> ![[WarewolfP.jpg|cover hsmall]]
> 
> ### Objective: 
> ????
> 
> ###  Quest Giver
> ????
> 
> ### Location
> ???
> 
> ### Reward
 ????
> ###  Faction

# <big><big><big> Additional Insight