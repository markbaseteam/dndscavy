

> [!infobox]
> # Session ??
>
> 
> | Started|
> | ---- |
| ?? |
> 
> |Finished|
>  | ---- |
>  | ?? |
>  
>|Encounters|
>| ---- |
>| ?? |
>
>|Loot Gained|
>| ---- |
>| ?? |
>
>|NPCs Met|
>| ---- |
>| ?? |

# <Big><Big><Big>