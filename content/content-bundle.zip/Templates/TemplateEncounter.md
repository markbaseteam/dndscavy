> [!infobox]
> # Name
> ![[GarrettP.png|cover hsmall]]
> 
> | What we fought|
> | ---- |
| ?? |
> 
> |Where|
>  | ---- |
>  | ?? |
>  
>|Relevant Skills/Spells|
>| ---- |
>| ?? |
>
>|Loot Acquired|
>| ---- |
>| ?? |
>
>|Session Fought in|
>| ---- |
>| ?? |

### <big> <big><big><big> Other Notes