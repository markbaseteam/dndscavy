> [!infobox]
> # Name
> ![[GarrettP.png|cover hsmall]]
>  ###  Geography
> 
> | Type |  Stat |
> | ---- | ---- |
> | Type | Town |
> | Size| Village |
> | Region | ??? |
> 
>   ###   Points of interest
> 
> | Type |  Stat |
> | ---- | ---- |
>| ?? |
> ### Society
> 
> | Type |  Stat |
> | ---- | ---- |
> | Demographics | ?? |
> | Population| ?? |
> | Religion | ?? |
> 
>### Affiliation
>  | Type |  Stat |
> | ---- | ---- |
> | ?? |?? |
>
> ### NPC
>  | Name |  Job |
> | ---- | ---- |
>  | ?? | ?? | 
> 
> ### Quests
>    ??

### <big> <big><big><big> What we did here


### <big> <big><big><big>  Notable Information


### <big> <big><big><big> Notable NPC




### <big> <big><big><big> Notable locations





-   Location Name: [Insert the name of the location here]
-   Location Description: [Describe the location, including its physical appearance, notable features, and any relevant history or background information.]
-   Location Inhabitants: [Describe the inhabitants of the location, including their race, class, and any notable personalities or factions. You can also include any potential opportunities for the player characters to interact with the inhabitants, such as offering quests or providing information.]
-   Location Hazards: [Describe any hazards or dangers that the player characters might encounter at the location, such as traps, hostile creatures, or environmental challenges.]
-   Location Rewards: [Describe any rewards that the player characters might gain by exploring the location, such as treasure, magical items, or valuable information.]
-   Location Connections: [Describe any connections the location has to other locations or plot points in your campaign, such as hidden passages, secret tunnels, or other ways to access the location.]