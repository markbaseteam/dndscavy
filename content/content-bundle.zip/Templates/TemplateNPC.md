> [!infobox]
> # Name
> ![[GarrettP.png|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
>*Status*| ?? |
> *Class*| ?? |
> *Level*| ?? |
> 
> |Physical Information|
>  | ---- | ---- |
>  *Age*| ??|
> *Race* | ?? |
> *Gender* | Male or Female  |
> *Height*| ?? |
> *Hair*| ?? |
> *Eyes*| ?? |
> 
> |General Information|
>  | ---- | ---- |
>  *Where We Me*| ?? |
>  *Relevance To Party*| ?? |
>  *Any Relations/Family*| ?? |

### <big><big><big>Other Important Information


NPC Personality: [Describe the NPC's personality, including their beliefs, motivations, and mannerisms. You can also include any quirks or memorable characteristics that will help you remember the NPC and role-play them effectively.]
NPC Background: [Provide a brief summary of the NPC's backstory, including where they came from, their family, and any significant events or experiences that have shaped who they are.]
NPC Relationships: [Describe any relationships the NPC has with other characters, including allies, enemies, and rivals. You can also include any potential opportunities for the NPC to interact with the player characters, such as offering quests or providing information.]