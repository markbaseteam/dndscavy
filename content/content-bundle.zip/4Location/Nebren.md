> [!infobox]
> # Nebren
> ![[PNGHEAR|cover hsmall]]
>  ###  Geography
> 
> | Type |  Stat |
> | ---- | ---- |
> | Type | Town |
> | Size| Village |
> | Region | ??? |
> 
>   ###   Points of interest
> 
> | Type |  Stat |
> | ---- | ---- |
>| ?? |
> ### Society
> 
> | Type |  Stat |
> | ---- | ---- |
> | Demographics | ?? |
> | Population| ?? |
> | Religion | ?? |
> 
>### Affiliation
>  | Type |  Stat |
> | ---- | ---- |
> | ?? |?? |
>
> ### NPC
>  | Name |  Job |
> | ---- | ---- |
>  | ?? | ?? | 
> 
> ### Quests
>    ??

### <big> <big><big><big> What we did here


### <big> <big><big><big>  Notable Information


### <big> <big><big><big> Notable NPC




### <big> <big><big><big> Notable locations
