```leaflet
id: leaflet-map
image: [[Map.png]]
height: 700px
lat: 70
long: 70
minZoom: 1
maxZoom: 10
defaultZoom: 7.49
unit: meters
scale: 1
marker: default, 39.983334, -82.983330, [[Note]]
darkMode: False
```