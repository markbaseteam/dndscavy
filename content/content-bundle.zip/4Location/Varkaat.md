> [!infobox]
> # Caius
> ![[PNGHEAR|cover hsmall]]
> ###### Stats
> | Type |  Stat |
> | ---- | ---- |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |
> | Test | Testing |

[[Cult of Batharium]]

[[Benjamin]]