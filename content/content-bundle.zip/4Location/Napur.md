> [!infobox]
> # Napur
> ![[PNGHEAR|cover hsmall]]
>  ###  Geography
> 
> | Type |  Stat |
> | ---- | ---- |
> | Type | Town |
> | Size| Village |
> | Region | ??? |
> 
>   ###   Points of interest
> 
> | Type |  Stat |
> | ---- | ---- |
>Tarvern
> ### Society
> 
> | Type |  Stat |
> | ---- | ---- |
> | Demographics | Human |
> | Population| ???? |
> | Religion | ???
> 
>### Affiliation
>  | Type |  Stat |
> | ---- | ---- |
> | ???|???
>
> ### NPC
>  | Name |  Job |
> | ---- | ---- |
>  [[Benjamin]] | Tavern Keep 
> 
> ### Quests
>    [[Kill Werewolf]]

### <big> <big><big><big> What we did here


### <big> <big><big><big>  Notable Information


### <big> <big><big><big> Notable NPC

[[Acererak]]


### <big> <big><big><big> Notable locations
