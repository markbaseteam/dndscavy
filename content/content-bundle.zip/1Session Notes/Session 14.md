

> [!infobox]
> # Session 14
>
> 
> | Started|
> | ---- |
| 2 floor |
> 
> |Finished|
>  | ---- |
>  | 3 floor|
>  
>|Encounters|
>| ---- |
>| Glass golem and 2 skeletons |
>
>|Loot Gained|
>| ---- |
>| Crust armor 2 arrows of slaying, Amulet of realm teleportation |
>
>|NPCs Met|
>| ---- |
>| Glass golem |

# <Big><Big><Big>
[[R'lykum]] 1 styrka  [[Eadan]] big   [[Caius]]  spawned new [[Eadan]]   [[Galmythe]] music


We did dungeon [[R'lykum]] dead.....

Orka skriva mer good luck future me