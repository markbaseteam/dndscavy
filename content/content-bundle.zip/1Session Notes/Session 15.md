

> [!infobox]
> # Session ??
>
> 
> | Started|
> | ---- |
| 3 floor |
> 
> |Finished|
>  | ---- |
>  | Outside the tempel |
>  
>|Encounters|
>| ---- |
>| None |
>
>|Loot Gained|
>| ---- |
>| ?? |
>
>|NPCs Met|
>| ---- |
>| Sisyphus   cultsist of [[RA]]     [[RA]]|

# <Big><Big><Big>Overview 






# <Big><Big><Big>Cell 

Met [[Sisyphus]] in a cell in [[The Gaze of RA]]
Kidnap by the  [[Cult of RA|cultist of RA]] was held there for A few weeks 2-4



# <Big>DOOM MUSIC START
 
Found a dark ball like a black hole was a spel that open a portal to the plane of [[RA]]




# <Big>MET GOD OF THE SUN ([[RA]]) 

Meet [[RA]] he was nice game me  knowles of Aberrations 

Told os about the sand god [[Xerxes]] 


# Notes taken during session
Cell
sisyphus
Human resembling a goliath, bandages over eyes
Muscular, thick and long beard and long hair
Kidnap by the cultis
Cutils of RA?
Blacksmith from a dwarven city and a warrior in war
A few weeks 2-4
Blindsight

DOOM MUSIC START

Chanting
Deep hum

dark ball like a black hole


Negativ sun dmasinol travul if intorupted coude introropted and big exploud

send sisyphus to the other side where [[RA]] lives

The cult want to bring  back the land to health

MET GOD OF THE SUN ([[RA]])

The desert is because of a GOD(of sand?)   name is xerxes

xerxes is known as the king of the desert, is basically the desert

Wizarding armor for ted

I got knowles of Aberrations From [[RA]]

Allan  metal staff
Ninni diamant
