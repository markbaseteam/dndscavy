

> [!infobox]
> # Session 11
>
> 
> | Started|
> | ---- |
| On the road to [[Nebren]] |
> 
> |Finished|
>  | ---- |
>  | Riund villeg |
>  
>|Encounters|
>| ---- |
>| Batids |
>
>|Loot Gained|
>| ---- |
>| Pokeballs |
>
>|NPCs Met|
>| ---- |
>| [[WerdMan]] |

# <Big><Big><Big>
On our journey to [[Nebren]] , we stumbled upon an oasis. The water was glowing blue, and upon testing, it seemed safe to drink. However, I am not entirely certain if it is truly safe. Only time will tell. We also discovered two caves while on the road. In the first cave, we found some strange metallic [[scraps]]. As we were leaving the cave, we were met by a Displacer Beast and its kin. We were lucky that we did not have to fight them. In the second cave, we found a sleeping [[WerdMan|man]] . I was able to sneak up to him and wake him up. He spoke in a language that none of us understood. He then escaped through another exit of the cave. Inside, we found a note and we copied it and left the original behind. We then left the cave and returned to the road.

On the side of the road, we came across a door that led to a house with three other doors. One led north, another led to an unknown island, and a third was a black door that we could not open. We did not find any use for the door, so we returned to the road.

We encountered some bandits in an abandoned village. They were not willing to share any food with us, so we killed them and I obtained some strange items called Pokeballs that can summon random animals.

