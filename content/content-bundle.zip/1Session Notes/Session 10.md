> [!infobox]
> # Session 10
>
> 
> | Started|
> | ---- |
> | Cave in [[Crossing Between Kingdoms]]|
> 
> |Finished|
> | ---- |
>  | On the road to [[Nebren]] |
>  
>|Encounters|
>| ---- |
>| None|
>
>|Loot Gained|
>| ---- |
>|Magical Longbow|
>
>|NPCs Met|
>| ---- |
>|[[Goliath]] Bar keeper of [[Eethan]] |

# <Big><Big><Big>Overview
After the wish incident, I, [[Garrett]] , obtained a magical longbow that can fire magical arrows that deal force damage. Together with [[R'lykum]] , we left the cave and encountered a 15-16 feet tall [[Goliath]] . He was there to collect on a deal that [[R'lykum]]  and [[Caius]] had made with a [[Priest of Batharium]] . [[R'lykum]] had agreed to give back a religious [[Religious book of batharium]] and pay 150 platinum and [[Caius]]  had agreed to return some stolen armor.

As we made our way back to [[Eethan]] , we found the village in chaos. We later learned from a lonesome ranger that our actions of feeding the bats had caused the village to be destroyed. We gathered the tavern keeper and set off towards [[Nebren]] , where we could find an air stone to travel to [[Zexarif]] .