

> [!infobox]
> # Session 12
>
> 
> | Started|
> | ---- |
| Riund villeg |
> 
> |Finished|
>  | ---- |
>  | Tenpel of [[RA]]  |
>  
>|Encounters|
>| ---- |
>| 4 Skeleton minotaurs |
>
>|Loot Gained|
>| ---- |
>| Emeral 100g |
>
>|NPCs Met|
>| ---- |
>| Cactus farmer old and ung man and [[Grobla]]|

# <Big><Big><Big>
We headed towards [[the Gaze of Ra]] and stumbled upon a cart pulled by a single camel. We decided to take the cart and encountered some cactus farmers on the way who kindly gave us two boxes of cacti. We thanked them and continued on our journey until we reached the temple.

As we entered the temple, we were greeted with a warning: "Go forth with seeing eyes and sword in hand  and you will meet death and avoid Anubis' eyes." Undeterred, we ventured deeper into the temple. On the first floor, we didn't encounter anything noteworthy. However, on the second floor, [[Eadan]] licked a black oss and nearly lost his tongue. We also fought against four skeleton minotaurs and discovered a goblin named [[Grobla]]. We decided to keep her as a pet.



# <Big><Big><Big> General
Bone claws? ward by [[Grobla]]
sumand by necromancer
Can't be killed until host is killed 


Tempel
Build in one week greenery better after it
Delad death 


Old man 60+ white  Cactus farmers
younger man 20 black skin  Cactus farmers  believers of [[ra]]
Two boxes 40 rations


Car found 7 rations