God of sand

Is the deserd that coverd the rigth of the [[Map]] 